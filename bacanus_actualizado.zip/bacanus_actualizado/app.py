from flask import Flask, render_template, request, redirect, session
import sqlite3
import os
from functools import wraps

app = Flask(__name__)
app.secret_key = 'bacanus_clave_secreta_2026'

# ============================
# CAMBIA ESTOS DATOS:
ADMIN_USUARIO = 'bacanus'
ADMIN_PASSWORD = 'tuclave123'
# ============================

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bacanus.db')

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS series (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT NOT NULL,
            descripcion TEXT,
            miniatura TEXT,
            orden INTEGER DEFAULT 0
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS episodios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            serie_id INTEGER NOT NULL,
            numero INTEGER NOT NULL,
            titulo TEXT NOT NULL,
            descripcion TEXT,
            url_youtube TEXT,
            url_mp4 TEXT,
            miniatura TEXT,
            duracion TEXT,
            FOREIGN KEY (serie_id) REFERENCES series(id)
        )
    ''')
    conn.commit()
    conn.close()

def login_requerido(f):
    @wraps(f)
    def decorador(*args, **kwargs):
        if not session.get('admin'):
            return redirect('/login')
        return f(*args, **kwargs)
    return decorador

# ===============================
# LOGIN / LOGOUT
# ===============================
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['usuario'] == ADMIN_USUARIO and request.form['password'] == ADMIN_PASSWORD:
            session['admin'] = True
            return redirect('/admin')
        else:
            error = 'Usuario o contraseña incorrectos'
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.pop('admin', None)
    return redirect('/')

# ===============================
# INICIO - lista de series
# ===============================
@app.route('/')
def index():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM series ORDER BY orden ASC, id ASC")
    series = cursor.fetchall()
    conn.close()
    return render_template('index.html', series=series)

# ===============================
# VER SERIE - lista de episodios
# ===============================
@app.route('/serie/<int:id>')
def ver_serie(id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM series WHERE id = ?", (id,))
    serie = cursor.fetchone()
    if serie is None:
        return redirect('/')
    cursor.execute("SELECT * FROM episodios WHERE serie_id = ? ORDER BY numero ASC", (id,))
    episodios = cursor.fetchall()
    conn.close()
    return render_template('serie.html', serie=serie, episodios=episodios)

# ===============================
# VER EPISODIO
# ===============================
@app.route('/episodio/<int:id>')
def ver_episodio(id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM episodios WHERE id = ?", (id,))
    episodio = cursor.fetchone()
    if episodio is None:
        return redirect('/')
    cursor.execute("SELECT * FROM series WHERE id = ?", (episodio['serie_id'],))
    serie = cursor.fetchone()
    cursor.execute("SELECT * FROM episodios WHERE serie_id = ? ORDER BY numero ASC", (episodio['serie_id'],))
    todos = cursor.fetchall()
    conn.close()
    return render_template('episodio.html', episodio=episodio, serie=serie, todos=todos)

# ===============================
# ADMIN - panel principal
# ===============================
@app.route('/admin')
@login_requerido
def admin():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM series ORDER BY orden ASC, id ASC")
    series = cursor.fetchall()
    conn.close()
    return render_template('admin.html', series=series)

# ===============================
# ADMIN - agregar serie
# ===============================
@app.route('/admin/agregar-serie', methods=['GET', 'POST'])
@login_requerido
def agregar_serie():
    if request.method == 'POST':
        titulo = request.form['titulo']
        descripcion = request.form['descripcion']
        miniatura = request.form['miniatura']
        orden = request.form.get('orden', 0)
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO series (titulo, descripcion, miniatura, orden) VALUES (?,?,?,?)",
            (titulo, descripcion, miniatura, orden)
        )
        conn.commit()
        conn.close()
        return redirect('/admin')
    return render_template('agregar_serie.html')

# ===============================
# ADMIN - editar serie
# ===============================
@app.route('/admin/editar-serie/<int:id>', methods=['GET', 'POST'])
@login_requerido
def editar_serie(id):
    conn = get_connection()
    cursor = conn.cursor()
    if request.method == 'POST':
        titulo = request.form['titulo']
        descripcion = request.form['descripcion']
        miniatura = request.form['miniatura']
        orden = request.form.get('orden', 0)
        cursor.execute(
            "UPDATE series SET titulo=?, descripcion=?, miniatura=?, orden=? WHERE id=?",
            (titulo, descripcion, miniatura, orden, id)
        )
        conn.commit()
        conn.close()
        return redirect('/admin')
    cursor.execute("SELECT * FROM series WHERE id = ?", (id,))
    serie = cursor.fetchone()
    conn.close()
    return render_template('editar_serie.html', serie=serie)

# ===============================
# ADMIN - eliminar serie
# ===============================
@app.route('/admin/eliminar-serie/<int:id>')
@login_requerido
def eliminar_serie(id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM episodios WHERE serie_id = ?", (id,))
    cursor.execute("DELETE FROM series WHERE id = ?", (id,))
    conn.commit()
    conn.close()
    return redirect('/admin')

# ===============================
# ADMIN - episodios de una serie
# ===============================
@app.route('/admin/serie/<int:serie_id>/episodios')
@login_requerido
def admin_episodios(serie_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM series WHERE id = ?", (serie_id,))
    serie = cursor.fetchone()
    cursor.execute("SELECT * FROM episodios WHERE serie_id = ? ORDER BY numero ASC", (serie_id,))
    episodios = cursor.fetchall()
    conn.close()
    return render_template('admin_episodios.html', serie=serie, episodios=episodios)

# ===============================
# ADMIN - agregar episodio
# ===============================
@app.route('/admin/serie/<int:serie_id>/agregar', methods=['GET', 'POST'])
@login_requerido
def agregar_episodio(serie_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM series WHERE id = ?", (serie_id,))
    serie = cursor.fetchone()
    if request.method == 'POST':
        numero = request.form['numero']
        titulo = request.form['titulo']
        descripcion = request.form['descripcion']
        url_youtube = request.form['url_youtube']
        url_mp4 = request.form['url_mp4']
        miniatura = request.form['miniatura']
        duracion = request.form['duracion']
        cursor.execute(
            "INSERT INTO episodios (serie_id, numero, titulo, descripcion, url_youtube, url_mp4, miniatura, duracion) VALUES (?,?,?,?,?,?,?,?)",
            (serie_id, numero, titulo, descripcion, url_youtube, url_mp4, miniatura, duracion)
        )
        conn.commit()
        conn.close()
        return redirect(f'/admin/serie/{serie_id}/episodios')
    conn.close()
    return render_template('agregar.html', serie=serie)

# ===============================
# ADMIN - editar episodio
# ===============================
@app.route('/admin/editar/<int:id>', methods=['GET', 'POST'])
@login_requerido
def editar_episodio(id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM episodios WHERE id = ?", (id,))
    episodio = cursor.fetchone()
    cursor.execute("SELECT * FROM series WHERE id = ?", (episodio['serie_id'],))
    serie = cursor.fetchone()
    if request.method == 'POST':
        numero = request.form['numero']
        titulo = request.form['titulo']
        descripcion = request.form['descripcion']
        url_youtube = request.form['url_youtube']
        url_mp4 = request.form['url_mp4']
        miniatura = request.form['miniatura']
        duracion = request.form['duracion']
        cursor.execute(
            "UPDATE episodios SET numero=?, titulo=?, descripcion=?, url_youtube=?, url_mp4=?, miniatura=?, duracion=? WHERE id=?",
            (numero, titulo, descripcion, url_youtube, url_mp4, miniatura, duracion, id)
        )
        conn.commit()
        conn.close()
        return redirect(f'/admin/serie/{serie["id"]}/episodios')
    conn.close()
    return render_template('editar.html', episodio=episodio, serie=serie)

# ===============================
# ADMIN - eliminar episodio
# ===============================
@app.route('/admin/eliminar/<int:id>')
@login_requerido
def eliminar_episodio(id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT serie_id FROM episodios WHERE id = ?", (id,))
    ep = cursor.fetchone()
    serie_id = ep['serie_id']
    cursor.execute("DELETE FROM episodios WHERE id = ?", (id,))
    conn.commit()
    conn.close()
    return redirect(f'/admin/serie/{serie_id}/episodios')

init_db()

if __name__ == '__main__':
    app.run(debug=True)
